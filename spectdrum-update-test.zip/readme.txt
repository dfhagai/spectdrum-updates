﻿Spectdrum update-mechanism test file. Safe to delete.
